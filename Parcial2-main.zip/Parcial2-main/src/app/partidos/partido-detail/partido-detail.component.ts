import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-partido-detail',
  templateUrl: './partido-detail.component.html',
  styleUrls: ['./partido-detail.component.css']
})
export class PartidoDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
